import random
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep

GM_Libary = ["Good morning, my love. Do you remember any of your dreams?", "I hope you’re feeling more well rested than I am this morning. I couldn’t fall asleep last night because I was thinking about how much I love you.",
             'Good morning, baby. I know it’s raining outside, but my head is full of sunshine thinking about you.',
             ' You know in the first Sex and the City movie, how Big had second thoughts about getting married to Carrie after the conversation he had with Miranda? I would never do that to you. He was a coward. Good morning.',
             'I hope you have a great day today, baby. You deserve all the best the world has to offer.',
             'I can’t believe you put up with me on top of everything else you have to deal with as a woman in this world. It’s insane. I’m not sure why you do it, but thank you and good morning.',
             'I wish I could have your period for you just once. Or, actually — no, I wish I could take it over forever. I’m sorry, baby. Have a good day.',
             'Good morning, babe. I can’t believe you exist. You are more than I could have ever hoped for, and I can’t believe I get to know you and love you.',
             ' Babe, you know what I was thinking about last night while I couldn’t fall asleep? The first time we met. I had no idea my life was about to change forever. You are wonderful.',
             'Knock-knock. (You say, “Who’s there?”) Your sweet love. (You say, “Your sweet love who?”) Your sweet love: Me! Good morning!',
            ]


print (random.choice(GM_Libary))

class autotexter:
    def __init__ (self, instagramID):
        self.instagramID = instagramID

    def instaDM(self):
        driver = webdriver.Chrome(r'C:\Users\danie\Desktop\Python Practice\pythonProject3\chromedriver')
        driver.get("https://www.instagram.com/")
        sleep(3)
        # find login
        login = driver.find_element_by_xpath('//*[@id="loginForm"]/div/div[1]/div/label/input')
        login.click()
        login.send_keys('ENTER ID HERE')

        pw = driver.find_element_by_xpath('//*[@id="loginForm"]/div/div[2]/div/label/input')
        pw.click()
        pw.send_keys('ENTER PASS WORD HERE')

        submit = driver.find_element_by_xpath('//*[@id="loginForm"]/div/div[3]')
        submit.click()

        sleep(4)

        notnow1 = driver.find_element_by_xpath('/html/body/div[1]/section/main/div/div/div/div/button')
        notnow1.click()
        sleep(3)
        nn2 = driver.find_element_by_xpath('/html/body/div[4]/div/div/div/div[3]/button[2]')
        nn2.click()
        sleep(3)

        driver.find_element_by_xpath('//*[@id="react-root"]/section/nav/div[2]/div/div/div[3]/div/div[2]/a/svg').click()
        driver.send_keys(self.instagramID)
        driver.send_keys(Keys.ENTER)
        sleep(4)

        driver.find_element_by_xpath('//*[@id="react-root"]/section/main/div/header/section/div[1]/div[1]/div/div[1]/div/button').click()
        driver.send_keys(random.choice(GM_Libary))
        driver.send_keys(random.choice(GM_Libary))
        driver.send_keys(Keys.ENTER)

        driver.close()


automate = autotexter(instagramID = "ENTER ID OF PERSON HERE")

automate.instaDM()
